
<?php $__env->startSection('content'); ?>


    <div class="card card-tale" style="background-color:#e9ecef; color:black; margin-bottom:2%;  margin-top:2%;">
        <div class="card-body">
            <p class="fs-30 mb-2" style="text-align:center;">Social Media Manegement</p>
        </div>
    </div>

    <div style="width:100%; height:auto;">

            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div id="errorBox" style="text-align:center;margin-top:20px;" class="alert alert-danger col-md-12 alert-dismissible fade show" role="alert">
                        <strong><?php echo $error; ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
                    </div>

                    <script>

                        setTimeout(
                        function()
                        {
                            $("#errorBox").delay(3000).fadeOut("slow");

                        }, 1000);

                    </script>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>


        <?php if(session()->has('message')): ?>

            <div id="successBox" style="text-align:center;margin-top:20px;" class="alert alert-success col-md-12 alert-dismissible fade show" role="alert">
                        <strong> <?php echo e(session()->get('message')); ?></strong>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                        </button>
            </div>

            <script>

                    setTimeout(
                    function()
                    {
                        $("#successBox").delay(3000).fadeOut("slow");

                    }, 1000);

            </script>

        <?php endif; ?>

    </div>


    <div class="jumbotron">

        <h3 style="text-align:center;">Insert Account Details</h3>
        <hr class="my-4">

        <form action="/insert-social-media-data" class="login100-form validate-form" method="POST" enctype="multipart/form-data">

            <?php echo e(csrf_field()); ?>


            <div class="form-group row">
                <label for="social_media" class="col-sm-2 col-form-label">Social Media</label>
                <div class="col-sm-10">
                <select class="form-control" id="social_media" name="social_media" style="color:black;" required>
                    <option value="" selected disabled hidden>Choose here</option>
                    <option>Facebook</option>
                    <option>Twitter</option>
                    <option>Instagram</option>
                    <option>Youtube</option>
                </select>
                </div>
            </div>

            <div class="form-group row">
              <label for="account_name" class="col-sm-2 col-form-label">Account Name</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="account_name" name="account_name" placeholder="Account Name" required>
              </div>
            </div>

            <div class="form-group row">
                <label for="account_type" class="col-sm-2 col-form-label">Account Type</label>
                <div class="col-sm-10">
                <select class="form-control" id="account_type" name="account_type" style="color:black;" required>
                    <option value="" selected disabled hidden>Choose here</option>
                    <option>Page</option>
                    <option>Profile</option>
                    <option>Other</option>
                </select>
                </div>
            </div>

            <div class="form-group row">
              <label for="url" class="col-sm-2 col-form-label">URL</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="url" name="url" placeholder="URL" required>
              </div>
            </div>


            <div class="form-group row">
              <label for="network_size" class="col-sm-2 col-form-label">Network Size</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="network_size" name="network_size" placeholder="Network Size">
              </div>
            </div>

            <div class="form-group row">
              <label for="main_user" class="col-sm-2 col-form-label">Main User</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="main_user" name="main_user" placeholder="Main User">
              </div>
            </div>


            <div class="form-group row">
                <label for="language" class="col-sm-2 col-form-label">Language</label>
                <div class="col-sm-10">
                <select class="form-control" id="language" name="language" style="color:black;" required>
                    <option value="" selected disabled hidden>Choose here</option>
                    <option>Sinhala</option>
                    <option>Tamil</option>
                </select>
                </div>
            </div>

            <div class="form-group row">
              <label for="remarks" class="col-sm-2 col-form-label">Remarks</label>
              <div class="col-sm-10">
                <textarea placeholder="remarks" class="form-control" id="remarks" name="Remarks" rows="3"></textarea>
              </div>
            </div>

            <input type="submit" value="Add" class="btn btn-success btn-lg btn-block">

        </form>

    </div>

    <div style="overflow-x:auto;">

        <table class="table table-hover" style="background-color:#e9ecef; color:black; margin-bottom:3%;">
            <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Social Media</th>
                    <th scope="col">Account Name</th>
                    <th scope="col">Account Type</th>
                    <th scope="col">URL</th>
                    <th scope="col">Network Size</th>
                    <th scope="col">Main User</th>
                    <th scope="col">Language</th>
                    <th scope="col">No.of.T Tested</th>
                    <th scope="col">Remarks</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                    <?php $__currentLoopData = $social_media_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <tr>
                            <th scope="row"><?php echo e($key + 1); ?></th>
                            <td><?php echo e($data->social_media); ?></td>
                            <td><?php echo e($data->account_name); ?></td>
                            <td><?php echo e($data->account_type); ?></td>
                            <td style="vertical-align: middle; line-height: 1; white-space: normal; line-height:120%;"><?php echo e($data->url); ?></td>
                            <td><?php echo e($data->network_size); ?></td>
                            <td><?php echo e($data->main_user_name); ?></td>
                            <td><?php echo e($data->language); ?></td>
                            <td><?php echo e($data->number_of_time_tested); ?></td>
                            <td style="vertical-align: middle; line-height: 1; white-space: normal; line-height:120%;"><?php echo e($data->remarks); ?></td>
                            <td><a class="btn btn-danger btn-sm confirmation" href="/delete-social-media-data/<?php echo e($data->auto_id); ?>">Delete</a> <a class="btn btn-success btn-sm" href="/view-social-media-data-edit-page/<?php echo e($data->auto_id); ?>">Edit</a></td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <script>

        window.onload = function(){

            $(".chosen-select").chosen({
                no_results_text: "Oops, nothing found!"
            })

            $('.confirmation').on('click', function () {
                return confirm('Are you sure to delete?');
            });

        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\the-project-aisle\03-basic-prototype-1\1-the-project-aisle-backend\resources\views/dashboard/social-media-management.blade.php ENDPATH**/ ?>