<?php $__env->startSection('content'); ?>


<div class="row" style="margin-top:2%; margin-left:2%; margin-right:2%;">

<div class="col-md-4 stretch-card grid-margin">
      <div class="card" style="background-color:#ebeff5;">
        <div class="card-body">
          
        <p class="card-title" style="text-align:center;">Top 10 Hate Speech Spreaders</p>
         
          <hr>
         
          <ul class="icon-data-list" style="width:100%;">

            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>

            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 

                </div>
              </div>
            </li>


            <li>
              <div class="d-flex">
                <img src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/face1.jpg" alt="user">
                <div style="width:100%;">

                  <p class="text-info mb-1">Isabella Becker  (No: 01)</p>

                    <div class="progress progress-md flex-grow-1 mr-12">
                            <div class="progress-bar bg-inf0" role="progressbar" style="width: 100%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                    <p class="mb-0" style="margin-top:1%;">140 (Times)</p>
                 
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>

    <div class="col-md-4 grid-margin">
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card" style="background-color:#ebeff5;">
                    <div class="card-body">
                        <p class="card-title" style="text-align:center;">Top 10 Trending Words</p>
                        <hr>
                        <div class="charts-data">
                        <div class="mt-3">
                            <p class="mb-0">Data 1</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-inf0" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">5k</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 2</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 35%" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">1k</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 3</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 48%" aria-valuenow="48" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">992</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        </div>  
                    </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-4 grid-margin">
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card" style="background-color:#ebeff5;">
                    <div class="card-body">
                        <p class="card-title" style="text-align:center;">Top 10 Trending Contexts</p>
                        <hr>
                        <div class="charts-data">
                        <div class="mt-3">
                            <p class="mb-0">Data 1</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-inf0" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">5k</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 2</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 35%" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">1k</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 3</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 48%" aria-valuenow="48" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">992</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        <div class="mt-3">
                            <p class="mb-0">Data 4</p>
                            <div class="d-flex justify-content-between align-items-center">
                            <div class="progress progress-md flex-grow-1 mr-4">
                                <div class="progress-bar bg-info" role="progressbar" style="width: 25%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                            <p class="mb-0">687</p>
                            </div>
                        </div>
                        </div>  
                    </div>
                    </div>
                </div>
            </div>
        </div>       
    </div>
<?php echo $__env->make('layouts.base-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\the-project-aisle\03-basic-prototype-1\1-the-project-aisle-backend\resources\views/dashboard/dashboard-home-page.blade.php ENDPATH**/ ?>