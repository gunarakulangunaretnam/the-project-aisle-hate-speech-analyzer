

<?php $__env->startSection('content'); ?>

<div class="card card-tale" style="background-color:#e9ecef; color:black; margin-bottom:2%;  margin-top:2%;">
    <div class="card-body">
        <p class="fs-30 mb-2" style="text-align:center;">Sinhala Language Rankings</p>
    </div>
</div>

<div class="row" style="margin-top:2%; margin-left:2%; margin-right:2%;">

<div class="col-md-6 grid-margin">
      <div class="card" style="background-color:#ebeff5;">
        <div class="card-body">

        <p class="card-title" style="text-align:center;">Hate Speech Spreaders</p>

          <hr>

          <ul class="icon-data-list" style="width:100%;">

            <?php $__currentLoopData = $SinhalaHateSpeechSpreadersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <li>

                    <div class="d-flex">
                      <div class="flex-grow-1 mr-1" style="margin-top:2.7%; margin-left:-2%; text-align:center; font-weight:bold;">

                        <?php echo e($loop->index != 9 ?  '0'.$loop->index+1 : $loop->index+1); ?>


                      </div>
                      <img style="margin-left:1.5%;" src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/default.jpg" alt="user">
                      <div style="width:100%;">
                          <p class="text-info mb-1"><?php echo e($sub_data[0]); ?></p>

                            <div class="progress progress-md flex-grow-1 mr-11">
                                  <div class="progress-bar bg-inf0" role="progressbar" style="width: <?php echo e($sub_data[2]); ?>%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                          <p class="mb-0" style="margin-top:1%;"><?php echo e($sub_data[1]); ?> (Times)</p>
                      </div>
                    </div>
                  </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </ul>

        </div>
      </div>
    </div>

    <div class="col-md-6 grid-margin">
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card" style="background-color:#ebeff5;">
                      <div class="card-body">
                          <p class="card-title" style="text-align:center;">Trending Keywords</p>
                          <hr>
                          <div class="charts-data row">

                          <?php $__currentLoopData = $SinhalaKeywordsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <div class="mt-4 flex-grow-1 col-md-2" style="margin-top:2.7%; margin-left:-2%; font-weight:bold;">

                                  <?php echo e($loop->index != 9 ?  '0'.$loop->index+1 : $loop->index+1); ?>


                                </div>

                                <div class="mt-2 col-md-10" style="margin-left:-5%;">
                                    <p class="mb-1"><?php echo e($sub_data[0]); ?></p>
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                      <div class="progress progress-md flex-grow-1">
                                          <div class="progress-bar bg-inf0" role="progressbar" style="width: <?php echo e($sub_data[2]); ?>%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                                      </div>

                                    </div>
                                    <p class="mb-0"><?php echo e($sub_data[1]); ?> (Repeated)</p>
                                </div>



                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

<div class="card card-tale" style="background-color:#e9ecef; color:black; margin-bottom:2%;  margin-top:2%;">
    <div class="card-body">
        <p class="fs-30 mb-2" style="text-align:center;">Tamil Language Rankings</p>
    </div>
</div>

<div class="row" style="margin-top:2%; margin-left:2%; margin-right:2%;">

<div class="col-md-6 grid-margin">
      <div class="card" style="background-color:#ebeff5;">
        <div class="card-body">
          <p class="card-title" style="text-align:center;">Hate Speech Spreaders</p>

          <hr>

          <ul class="icon-data-list" style="width:100%;">

            <?php $__currentLoopData = $TamilHateSpeechSpreadersData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <li>

                    <div class="d-flex">
                      <div class="flex-grow-1 mr-1" style="margin-top:2.7%; margin-left:-2%; text-align:center; font-weight:bold;">

                        <?php echo e($loop->index != 9 ?  '0'.$loop->index+1 : $loop->index+1); ?>


                      </div>
                      <img style="margin-left:1.5%;" src="<?php echo e(asset('dashboard-page-asset')); ?>/images/faces/default.jpg" alt="user">
                      <div style="width:100%;">
                          <p class="text-info mb-1"><?php echo e($sub_data[0]); ?></p>

                            <div class="progress progress-md flex-grow-1 mr-11">
                                  <div class="progress-bar bg-inf0" role="progressbar" style="width: <?php echo e($sub_data[2]); ?>%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                            </div>
                          <p class="mb-0" style="margin-top:1%;"><?php echo e($sub_data[1]); ?> (Times)</p>
                      </div>
                    </div>
                  </li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

          </ul>

        </div>
      </div>
    </div>

    <div class="col-md-6 grid-margin">
            <div class="row">
                <div class="col-md-12 grid-margin stretch-card">
                    <div class="card" style="background-color:#ebeff5;">

                        <div class="card-body">
                          <p class="card-title" style="text-align:center;">Trending Keywords</p>
                          <hr>
                          <div class="charts-data row">

                          <?php $__currentLoopData = $TamilKeywordsData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                                <div class="mt-4 flex-grow-1 col-md-2" style="margin-top:2.7%; margin-left:-2%; font-weight:bold;">

                                  <?php echo e($loop->index != 9 ?  '0'.$loop->index+1 : $loop->index+1); ?>


                                </div>

                                <div class="mt-2 col-md-10" style="margin-left:-5%;">
                                    <p class="mb-1"><?php echo e($sub_data[0]); ?></p>
                                    <div class="d-flex justify-content-between align-items-center mb-1">
                                      <div class="progress progress-md flex-grow-1">
                                          <div class="progress-bar bg-inf0" role="progressbar" style="width: <?php echo e($sub_data[2]); ?>%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                                      </div>

                                    </div>
                                    <p class="mb-0"><?php echo e($sub_data[1]); ?> (Repeated)</p>
                                </div>

                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                          </div>
                      </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\the-project-aisle\03-basic-prototype-1\1-the-project-aisle-backend\resources\views/dashboard/analytics-rankings-page.blade.php ENDPATH**/ ?>